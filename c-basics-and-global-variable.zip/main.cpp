 #include<iostream>
 #include<iomanip>
 using namespace std;
 
 int glo = 11;      //Global Variable (can access through Scope Resolution Operartor '::')
 
 class Complex {
     //private:     //By default it will be private only , no need to write
    int real,imaginary;
    public:
        void setData(int a , int b){
            real = a;
            imaginary = b;
        }
        
        void getData(void){
            cout<<"The Value of Complex Number is: "<<real<<" + "<<imaginary<<"i"<<endl;
        }
 };
 
 void function_Glo(void){
     int glo = 99;
     cout<<"Function Glo: "<<glo<<endl;
 }
 
 
 
 
 int main(){
    
    /* Printing the Global variable and Local variable */ 
    int glo= 7;
    function_Glo();
    cout<<"Main's glo: "<<glo<<endl;
    cout<<"Global variable: "<<::glo<<endl; //use Scope Resolution Operartor for printing global var
    
    cout<<endl;
    
     
    /* Program for Complex number */
    int p ,q , n;
    Complex obj;
    
    cout<<"How many total complex number is there: ?\n" ;
    cin>>n;
    
    for(int i=0 ; i<n ;i++){
    cout<<"<<<---------------***------------------->>>"<<endl;
     cout<<"Enter the Real Part of complex number: "<<i+1<<endl;
     cin>>p;
     cout<<"Enter the Imaginary Part of complex number"<<i+1<<endl;
     cin>>q;
     obj.setData(p,q);
     obj.getData();
     cout<<endl;
    } 
    
    
     
     
     
     
     
     
     
     
     return 0;
 }